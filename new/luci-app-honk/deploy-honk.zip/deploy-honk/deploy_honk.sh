#!/bin/sh
# ============================================================================
#  luci-app-honk 页面改造 热部署脚本
#
#  用法（路由器上，root）：
#    sh deploy_honk.sh apply     备份原文件并部署（可重复执行）
#    sh deploy_honk.sh rollback  回退到最近一次备份
#    sh deploy_honk.sh list      查看备份列表
#    sh deploy_honk.sh check     核对部署结果
#
#  说明：
#    1. 备份保存在 /root/honk-deploy-backup/<时间戳>/，可随时回退；
#    2. apply 不会中断正在运行的 honk 服务；
#    3. 部署后浏览器务必 Ctrl+F5 强制刷新；
#    4. 热部署后 opkg 数据库与实际文件不同步，以后 opkg upgrade
#       会覆盖回原版，重新执行一次 apply 即可。
# ============================================================================

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
FILES_DIR="$BASE_DIR/files"
BACKUP_ROOT="/root/honk-deploy-backup"

# 源文件相对路径|目标绝对路径|权限
FILE_LIST="www/luci-static/resources/honk/common.js|/www/luci-static/resources/honk/common.js|0644
www/luci-static/resources/view/honk/global.js|/www/luci-static/resources/view/honk/global.js|0644
usr/share/rpcd/ucode/honk.uc|/usr/share/rpcd/ucode/honk.uc|0755
usr/lib/lua/luci/i18n/honk.zh-cn.lmo|/usr/lib/lua/luci/i18n/honk.zh-cn.lmo|0644
etc/init.d/honk|/etc/init.d/honk|0755"

log()  { echo "[deploy] $*"; }
warn() { echo "[deploy][WARN] $*" >&2; }
die()  { echo "[deploy][ERROR] $*" >&2; exit 1; }

md5_of() { md5sum "$1" 2>/dev/null | awk '{print $1}'; }

require_root() {
	[ "$(id -u)" = "0" ] || die "请以 root 身份执行"
}

refresh_ui() {
	/etc/init.d/rpcd reload >/dev/null 2>&1 || /etc/init.d/rpcd restart >/dev/null 2>&1
	rm -rf /tmp/luci-modulecache 2>/dev/null
	rm -f /tmp/luci-indexcache /tmp/luci-indexcache.* 2>/dev/null
}

uci_cleanup() {
	# 清理已废弃的 enabled / advanced 配置项（不再参与任何逻辑）
	if command -v uci >/dev/null 2>&1; then
		uci -q delete honk.config.enabled 2>/dev/null
		uci -q delete honk.config.advanced 2>/dev/null
		uci -q commit honk 2>/dev/null
	fi
}

do_apply() {
	require_root
	[ -d "$FILES_DIR" ] || die "找不到 files 目录：$FILES_DIR"

	ts="$(date +%Y%m%d-%H%M%S)"
	bdir="$BACKUP_ROOT/$ts"
	mkdir -p "$bdir/files" || die "无法创建备份目录：$bdir"

	log "备份原文件到 $bdir"
	while IFS='|' read -r rel dest mode; do
		[ -n "$rel" ] || continue
		src="$FILES_DIR/$rel"
		[ -f "$src" ] || die "缺少源文件：$src"

		if [ -f "$dest" ]; then
			orig_mode="$(stat -c '%a' "$dest" 2>/dev/null)"
			mkdir -p "$bdir/files/$(dirname "$rel")"
			cp -a "$dest" "$bdir/files/$rel"
		else
			orig_mode="-"
		fi
		echo "$rel|$dest|$orig_mode" >> "$bdir/manifest.txt"
	done <<EOF
$FILE_LIST
EOF

	log "部署文件"
	while IFS='|' read -r rel dest mode; do
		[ -n "$rel" ] || continue
		src="$FILES_DIR/$rel"
		mkdir -p "$(dirname "$dest")"
		cp "$src" "$dest.tmp.$$" || die "写入失败：$dest"
		chmod "$mode" "$dest.tmp.$$"
		mv -f "$dest.tmp.$$" "$dest"

		smd="$(md5_of "$src")"
		dmd="$(md5_of "$dest")"
		[ "$smd" = "$dmd" ] || die "MD5 校验失败：$dest"
		log "  OK $dest"
	done <<EOF
$FILE_LIST
EOF

	uci_cleanup
	refresh_ui

	log "完成。请在浏览器 Ctrl+F5 强制刷新。"
	log "如需回退：sh $0 rollback"
}

do_rollback() {
	require_root
	bdir="$(ls -1d "$BACKUP_ROOT"/*/ 2>/dev/null | sort | tail -n 1)"
	[ -n "$bdir" ] || die "没有可用的备份（$BACKUP_ROOT）"
	bdir="${bdir%/}"
	[ -f "$bdir/manifest.txt" ] || die "备份缺少 manifest：$bdir"

	log "回退到备份：$bdir"
	while IFS='|' read -r rel dest orig_mode; do
		[ -n "$rel" ] || continue
		if [ "$orig_mode" = "-" ]; then
			# 部署前并不存在的文件，回退时移除
			rm -f "$dest"
			log "  RM $dest"
		else
			[ -f "$bdir/files/$rel" ] || { warn "备份缺失 $rel，跳过"; continue; }
			cp "$bdir/files/$rel" "$dest"
			chmod "$orig_mode" "$dest"
			log "  OK $dest"
		fi
	done < "$bdir/manifest.txt"

	refresh_ui
	log "回退完成。请在浏览器 Ctrl+F5 强制刷新。"
}

do_list() {
	if [ -d "$BACKUP_ROOT" ]; then
		ls -1 "$BACKUP_ROOT"
	else
		log "暂无备份"
	fi
}

do_check() {
	fail=0
	while IFS='|' read -r rel dest mode; do
		[ -n "$rel" ] || continue
		src="$FILES_DIR/$rel"
		if [ ! -f "$dest" ]; then
			echo "MISSING  $dest"
			fail=1
			continue
		fi
		smd="$(md5_of "$src")"
		dmd="$(md5_of "$dest")"
		if [ "$smd" = "$dmd" ]; then
			echo "OK       $dest"
		else
			echo "DIFF     $dest"
			fail=1
		fi
	done <<EOF
$FILE_LIST
EOF

	# 配置项清理核对
	if command -v uci >/dev/null 2>&1; then
		[ -n "$(uci -q get honk.config.enabled)" ] && { echo "DIFF     /etc/config/honk 残留 option enabled"; fail=1; }
		[ -n "$(uci -q get honk.config.advanced)" ] && { echo "DIFF     /etc/config/honk 残留 option advanced"; fail=1; }
	fi

	[ "$fail" = "0" ] && log "部署核对通过" || log "存在差异，请重新执行 apply"
	return $fail
}

case "$1" in
	apply)    do_apply ;;
	rollback) do_rollback ;;
	list)     do_list ;;
	check)    do_check ;;
	*)
		echo "用法: sh $0 apply|rollback|list|check"
		exit 1
		;;
esac
